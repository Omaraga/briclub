<?php
return [
    'adminEmail' => 'admin@shanyrakplus.com',
    'supportEmail' => 'info@shanyrakplus.com',
    'user.passwordResetTokenExpire' => 3600,
    'public_password' => '0aa5a6e159d2d68b42ac4c217cb71589',
    'public_id' => 'pk_e20442adc77519a57bf082958b2ac',
];
