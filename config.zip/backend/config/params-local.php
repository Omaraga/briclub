<?php
return [
    'mainUrl' => 'https://shanyrakplus.com',
    //'mainUrl' => 'http://gcfond2.loc',
];
