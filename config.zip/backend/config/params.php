<?php
return [
    'adminEmail' => 'omaraga@mail.ru',
    'mainUrl' => 'https://shanyrakplus.com',
    //'mainUrl' => 'http://gcfond2.loc',
    'PayerAccount' => 'U24477392',
    'AccountID' => '9256519',
    'PassPhrase' => '6868R5T6Y7',
    'PassPhrase2' => 'IeSw99qa7SkF4v2DGiaIMRNoi',
];
