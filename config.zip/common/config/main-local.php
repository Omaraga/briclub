<?php
return [
    'components' => [
        /*'mailer' => [
            'useFileTransport' => false,
            'class' => 'yii\swiftmailer\Mailer',
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.mail.ru', //вставляем имя или адрес почтового сервера
                'username' => 'noreply@gcfond.com',
                'password' => 'cZi7CZjia8(NzC4',
                'port' => '465',
                'encryption' => 'ssl',
                'streamOptions' =>[
                    'ssl' => [
                        'verify_peer' => true,
                        'verify_peer_name' => true,
                    ],
                ],
            ],
        ],*/
    ],
];
