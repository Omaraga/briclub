<?php
return [
    'adminEmail' => 'omaraga@mail.ru',
    'supportEmail' => 'omaraga@mail.ru',
    'user.passwordResetTokenExpire' => 3600,
    'public_password' => '0aa5a6e159d2d68b42ac4c217cb71589',
    'public_id' => 'pk_e20442adc77519a57bf082958b2ac',
    'coin.private_key' => '454e78e64430b0E9913Dad4DDED8924b686a44a00717fA4Dace9aE5cfc64774B',
    'coin.public_key' => '304e24e6c09f51796f362e8e7d052ca3ffda2913d08d6358866da136a11bc930',
];
