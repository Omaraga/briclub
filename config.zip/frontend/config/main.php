<?php
$params = array_merge(
    require __DIR__ . '/../../common/config/params.php',
    require __DIR__ . '/../../common/config/params-local.php',
    require __DIR__ . '/params.php',
    require __DIR__ . '/params-local.php'
);

return [
    'id' => 'app-frontend',
    'name' => 'Shanyrakplus.com',
    'basePath' => dirname(__DIR__),
    'bootstrap' => [
        'log',
        'frontend\components\DynaRoute',
    ],
    'timeZone' => 'Asia/Almaty',
    'controllerNamespace' => 'frontend\controllers',
    'components' => [

        'request' => [
            'csrfParam' => '_csrf-frontend',
            'baseUrl' => ''
        ],

        'user' => [
            'identityClass' => 'common\models\User',
            'enableAutoLogin' => true,
            'identityCookie' => ['name' => '_identity-frontend', 'httpOnly' => true],
        ],
        'session' => [
            // this is the name of the session cookie used for login on the frontend
            'name' => 'advanced-frontend',
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],

        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                '/logout' => 'site/logout',
                '' => '/academy',
                '/requestPasswordReset' => 'site/request-password-reset',
                '/confirm-email' => 'site/confirm-email',
                '/new-user' => 'site/new-user',
                '/profile/settings/<tabName:personal|safety>' => 'profile/settings',//для определение какой таб откырть (personal - личные данные, safety-пароль)
                '/reset-password' => 'site/reset-password',
                '/profile/theme/<currTheme>' => 'profile/theme',
                '/profile/theme' => 'profile/theme',
                '/profile/structure/<id>' => 'profile/structure',
                '/profile/start/<id>' => 'profile/start',
                '/profile/matrix/<id>' => 'profile/matrix',
                '/profile/tickets/<id>' => 'profile/tickets',
                '/profile/actions/<id>' => 'profile/actions',
                '/invite/<userName>/<showStatistic:1|0>' => 'site/invite',
                '/invite/<userName>' => 'site/invite',
                '/profile/statistic/<type:week|month|year>/<currTab>' => 'profile/statistic',
				'/news' => 'news/index',
                '/news/<id>' => 'news/index',
				'/events' => 'events/index',
                '/events/<id>' => 'events/index',
                '/course/<id>' => 'course/index',
                '/course/view/<id>' => 'course/view',
                '/anti.html' => 'site/anti',
				'/library/<id>' => 'library/index',
                '/edu.html' => 'site/edu',
                '/index.html' => 'site',
                '/advcash' => '/advcash/advcash/index',
                '/advcash-withdraws/<action>' => '/advcash/advcash-api/<action>',
                '/advcash-deposits/<action>' => '/advcash/advcash-sci/<action>',
            ],
        ],
        'assetManager' => [
            'bundles' => [
                'yii\web\JqueryAsset' => [
                    'sourcePath' => null,   // do not publish the bundle
                    'js' => [
                        'https://code.jquery.com/jquery-3.4.1.min.js',
                        'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js'
                    ]
                ],
            ],
        ],
        'mailer' => [
            'useFileTransport' => false,
            'class' => 'yii\swiftmailer\Mailer',
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.mail.ru', //вставляем имя или адрес почтового сервера
                'username' => 'omaraga@mail.ru',
                'password' => '1351969Gemini@',
                'port' => '587',
                'encryption' => 'tls',

            ],
        ],
    ],
    'modules' => [
        'advcash' => [
            'class' => 'frontend\modules\advcash\AdvcashPayment',
        ],
        'academy' => [
            'class' => 'frontend\modules\academy\Module',
        ],
    ],

    'params' => $params,
    //'defaultRoute' => '/',
];
