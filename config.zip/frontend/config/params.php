<?php
return [
    'adminEmail' => 'omaraga@mail.ru',
    'main_url' => 'https://shanyrakplus.com',
];
